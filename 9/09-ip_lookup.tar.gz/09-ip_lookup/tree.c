#include "tree.h"
#include <stdio.h>
#include <stdlib.h>

// return an array of ip represented by an unsigned integer, the length of array is TEST_SIZE
uint32_t* read_test_data(const char* lookup_file){
    fprintf(stderr,"TODO:%s",__func__);
    return NULL;
}
// Constructing an basic trie-tree to lookup according to `forward_file`
void create_tree(const char* forward_file){
    fprintf(stderr,"TODO:%s",__func__);
}

// Look up the ports of ip in file `ip_to_lookup.txt` using the basic tree, input is read from `read_test_data` func 
uint32_t *lookup_tree(uint32_t* ip_vec){
    fprintf(stderr,"TODO:%s",__func__);
    return NULL;
}
// Constructing an advanced trie-tree to lookup according to `forward_file`
void create_tree_advance(const char* forward_file){
    fprintf(stderr,"TODO:%s",__func__);
}

// Look up the ports of ip in file `ip_to_lookup.txt` using the advanced tree input is read from `read_test_data` func 
uint32_t *lookup_tree_advance(uint32_t* ip_vec){
    fprintf(stderr,"TODO:%s",__func__);
    return NULL;
}





